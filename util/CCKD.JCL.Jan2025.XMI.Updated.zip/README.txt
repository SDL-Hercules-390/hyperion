--------------------------------------------------------------------------------

                     "CCKD.JCL.Jan2025.XMI.Updated.zip"


                             ***  README  ***


                                 HERCULES

                       CCKDDUMP, CCKDDU64, CCKDLOAD


                        Copy an entire MVS volume
                       to a very large MVS dataset
                       which can then be downloaded
                     to your PC and added to Hercules
                              (or vice-versa)

--------------------------------------------------------------------------------

The complete package for CCKDDUMP/CCKDDU64 and CCKDLOAD, is created in TSO XMIT
format and included in this zip file with the name "CCKD.JCL.Jan2025.XMI".


  1)  Extract "CCKD.JCL.Jan2025.XMI" from this zip file into a folder on your PC


  2)  Preallocate a dataset on MVS with LRECL=80,BLKSIZE=3120,RECFM=FB,DSORG=PS
      with SPACE of 75 Tracks.


  3)  Upload "CCKD.JCL.Jan2025.XMI" from your PC to your preallocated dataset on
      MVS using *binary* transfer mode (no CRLF or ASCII translation!).


  4)  RECEIVE the preallocated dataset on MVS:

      Issue the command: "TSO RECEIVE INDATASET(your.preallocated.dataset)"

      When prompted by message:

          "INMR906A Enter restore parameters or 'DELETE' or 'END'

      enter:

          "DA(name.of.a.new.cckd.library) UNIT(unit) VOLUME(volume)"

        e.g. DA(CCKD.JCL) UNIT(3390) VOL(WRKVOL)


  5)  Follow the rest of the instructions in the "$$README" member of the PDS
      just RECEIVED.

--------------------------------------------------------------------------------

                                 Credits

Original author of the Hercules CCKDDUMP/CCKDLOAD package: Greg Smith, a former
(now deceased) Hercules developer. CCKDDU64 is a CCKD64 version of CCKDDUMP to
handle very large model 3390 dasds such as 3390-54, and was created and debugged
by several very talented Hercules users, the most noteworthy of which is Andrew.

--------------------------------------------------------------------------------
